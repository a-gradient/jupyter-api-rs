## spec.yaml
https://github.com/jupyter-server/jupyter_server/blob/main/jupyter_server/services/api/api.yaml
